/**
 * This file is part of CloudML [ http://cloudml.org ]
 *
 * Copyright (C) 2012 - SINTEF ICT
 * Contact: Franck Chauvel <franck.chauvel@sintef.no>
 *
 * Module: root
 *
 * CloudML is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * CloudML is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with CloudML. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.cloudml.connectors.samples;

import java.io.File;
import java.util.Collection;
import org.cloudml.connectors.AwsRDSConnector;
import org.cloudml.connectors.BeanstalkConnector;

/**
 *
 * @author huis
 */
public class BeanstalkConnectorExample {
        
    public static void main(String[] args){
        String accessKey = "";
        String secretKey = "";
        String endpoint = "elasticbeanstalk.us-east-1.amazonaws.com";
        
        BeanstalkConnector connector = new BeanstalkConnector(
                accessKey,
                secretKey,
                endpoint
        );
        
        String appName = "granny-cloudml-app";
        String envName = "granny-cloudml-env";
        String dbInstanceName = "granny-cloudml-db";
        connector.createApplication(appName);
        
        connector.createEnvironmentWithWar(appName, appName, 
                envName, "Tomcat 7", new File("C:\\temp\\granny-beanstalk-6.war"),"0.0.1");
        Collection<String> ips = connector.getEnvIPs("granny-sintef-cloudml1");
        
        AwsRDSConnector rdsConnector = new AwsRDSConnector(accessKey, secretKey, "rds.us-east-1.amazonaws.com");
        
        rdsConnector.createDBInstance("mysql", "5.5.33", dbInstanceName, "ebdb", "sintef", "password123", 5, "");
        
        
        /** This need to be executed after the instance is ready !*/
        //rdsConnector.createAndSetSecuretGroup(envName,ips);
        /**-------------------*/
    }
    
}
